<template>
  <div class="excel-reader">
    <h2 class="title">Excel Reader</h2>
    
    <!-- 文件上传区域 -->
    <div class="upload-section">
      <label class="upload-button" for="file-upload">
        <i class="upload-icon">📁</i>
        Upload Excel File
      </label>
      <input 
        id="file-upload"
        type="file"
        accept=".xlsx,.xls"
        @change="handleFileUpload"
        class="hidden-input"
      >
    </div>

    <!-- 文件列表 -->
    <div class="file-list" v-if="excelFiles.length > 0">
      <div 
        v-for="file in excelFiles" 
        :key="file"
        class="file-button"
        :class="{ active: currentFile === file }"
        @click="loadExcelFile(file)"
      >
        {{ file }}
      </div>
    </div>

    <!-- 加载状态 -->
    <div v-if="loading" class="loading">
      <div class="loading-spinner"></div>
      Loading...
    </div>

    <!-- 错误提示 -->
    <div v-else-if="error" class="error">
      <i class="error-icon">⚠</i>
      Error: {{ error }}
    </div>

    <!-- 数据展示 -->
    <div v-else class="content">
      <div v-if="currentFileData" class="file-section">
        <h3 class="file-name">{{ currentFile }}</h3>
        <div class="json-viewer">
          <pre v-html="formatJSON(currentFileData)"></pre>
        </div>
      </div>
      <div v-else class="empty-state">
        Please select or upload an Excel file to view its contents
      </div>
    </div>
  </div>
</template>

<script>
import { ref, onMounted } from 'vue';
import { readAllExcelFiles } from '../utils/excelReader';
import * as XLSX from 'xlsx';

export default {
  name: 'ExcelReader',
  setup() {
    const excelData = ref({});
    const loading = ref(false);
    const error = ref(null);
    const currentFile = ref('');
    const currentFileData = ref(null);
    const excelFiles = ref(['users.xlsx', 'products.xlsx']);

    const formatJSON = (obj) => {
      const jsonString = JSON.stringify(obj, null, 2);
      return jsonString.replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*"(\s*:)?|\b(true|false|null)\b|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)/g, (match) => {
          let cls = 'number';
          if (/^"/.test(match)) {
            if (/:$/.test(match)) {
              cls = 'key';
            } else {
              cls = 'string';
            }
          } else if (/true|false/.test(match)) {
            cls = 'boolean';
          } else if (/null/.test(match)) {
            cls = 'null';
          }
          return `<span class="${cls}">${match}</span>`;
        });
    };

    const handleFileUpload = async (event) => {
      const file = event.target.files[0];
      if (!file) return;

      try {
        loading.value = true;
        error.value = null;

        // 读取文件内容
        const reader = new FileReader();
        reader.onload = async (e) => {
          try {
            const data = new Uint8Array(e.target.result);
            const workbook = XLSX.read(data, { type: 'array' });
            
            // 获取所有工作表的数据
            const result = {};
            workbook.SheetNames.forEach(sheetName => {
              const worksheet = workbook.Sheets[sheetName];
              result[sheetName] = XLSX.utils.sheet_to_json(worksheet);
            });

            // 更新数据和状态
            currentFile.value = file.name;
            currentFileData.value = result;
            
            // 添加到文件列表（如果不存在）
            if (!excelFiles.value.includes(file.name)) {
              excelFiles.value.push(file.name);
            }

            loading.value = false;
          } catch (err) {
            error.value = `Failed to parse Excel file: ${err.message}`;
            loading.value = false;
          }
        };

        reader.onerror = () => {
          error.value = 'Failed to read file';
          loading.value = false;
        };

        reader.readAsArrayBuffer(file);
      } catch (err) {
        error.value = err.message;
        loading.value = false;
      }
    };

    const loadExcelFile = async (fileName) => {
      try {
        loading.value = true;
        error.value = null;
        currentFile.value = fileName;
        const result = await readAllExcelFiles([fileName]);
        currentFileData.value = result[fileName];
      } catch (err) {
        error.value = err.message;
      } finally {
        loading.value = false;
      }
    };

    onMounted(() => {
      if (excelFiles.value.length > 0) {
        loadExcelFile(excelFiles.value[0]);
      }
    });

    return {
      excelFiles,
      currentFile,
      currentFileData,
      loading,
      error,
      formatJSON,
      loadExcelFile,
      handleFileUpload
    }
  }
}
</script>

<style scoped>
.excel-reader {
  padding: 20px;
  max-width: 1200px;
  margin: 0 auto;
}

.title {
  color: #2c3e50;
  margin-bottom: 20px;
  font-size: 2em;
  text-align: center;
}

.upload-section {
  margin-bottom: 20px;
  text-align: center;
}

.upload-button {
  display: inline-flex;
  align-items: center;
  padding: 12px 24px;
  background: #4CAF50;
  color: white;
  border-radius: 4px;
  cursor: pointer;
  transition: background-color 0.3s;
  font-size: 1.1em;
}

.upload-button:hover {
  background: #45a049;
}

.upload-icon {
  margin-right: 8px;
  font-style: normal;
}

.hidden-input {
  display: none;
}

.empty-state {
  text-align: center;
  padding: 40px;
  color: #666;
  font-size: 1.1em;
  background: #f8f9fa;
  border-radius: 8px;
}

.file-list {
  display: flex;
  gap: 10px;
  margin-bottom: 20px;
  flex-wrap: wrap;
}

.file-button {
  padding: 8px 16px;
  background: #f8f9fa;
  border: 1px solid #dee2e6;
  border-radius: 4px;
  cursor: pointer;
  transition: all 0.2s;
}

.file-button:hover {
  background: #e9ecef;
}

.file-button.active {
  background: #007bff;
  color: white;
  border-color: #0056b3;
}

.loading {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 20px;
  color: #666;
  font-size: 1.2em;
}

.loading-spinner {
  border: 4px solid #f3f3f3;
  border-top: 4px solid #3498db;
  border-radius: 50%;
  width: 24px;
  height: 24px;
  animation: spin 1s linear infinite;
  margin-right: 10px;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.error {
  background-color: #fee;
  color: #c00;
  padding: 15px;
  border-radius: 4px;
  display: flex;
  align-items: center;
  margin: 10px 0;
}

.error-icon {
  margin-right: 10px;
  font-style: normal;
  font-size: 1.2em;
}

.file-section {
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  margin-bottom: 30px;
  overflow: hidden;
}

.file-name {
  background: #f8f9fa;
  color: #2c3e50;
  margin: 0;
  padding: 15px;
  border-bottom: 1px solid #eee;
}

.json-viewer {
  padding: 20px;
  background: #1e1e1e;
  overflow-x: auto;
}

.json-viewer pre {
  margin: 0;
  font-family: 'Consolas', 'Monaco', monospace;
  font-size: 14px;
  line-height: 1.5;
  color: #d4d4d4;
  white-space: pre-wrap;
  word-wrap: break-word;
}

/* JSON syntax highlighting */
.json-viewer .key {
  color: #9cdcfe;
}

.json-viewer .string {
  color: #ce9178;
}

.json-viewer .number {
  color: #b5cea8;
}

.json-viewer .boolean {
  color: #569cd6;
}

.json-viewer .null {
  color: #569cd6;
}

@media (max-width: 768px) {
  .excel-reader {
    padding: 10px;
  }
  
  .json-viewer {
    font-size: 12px;
  }

  .upload-button {
    padding: 10px 20px;
    font-size: 1em;
  }
}
</style>
