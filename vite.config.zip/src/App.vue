<template>
  <div id="app">
    <excel-reader />
  </div>
</template>

<script>
import ExcelReader from './components/ExcelReader.vue'

export default {
  name: 'App',
  components: {
    ExcelReader
  }
}
</script>

<style>
#app {
  font-family: Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
